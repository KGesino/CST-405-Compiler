int x;
int y;
int z;
int r;

x = 10;
y = 20;
z = x + y;
print(z);

x = z + 5;
print(x);

r = x - 3;
print(r);

y = x + y + z;
print(y);

int a[10];
int i;
int result;

i = 0;
a[i] = 100;

i = 1;
a[i] = 200;

i = 2;
a[i] = 300;

print(a[1]);

result = a[0] + a[2];
print(result);

i = 1;
a[i + 1] = 999;
print(a[2]);

int v0; int v1; int v2; int v3; int v4; int v5; int v6; int v7; int v8; int v9;
int v10; int v11; int v12; int v13; int v14; int v15; int v16; int v17; int v18; int v19;
int v20; int v21; int v22; int v23; int v24; int v25; int v26; int v27; int v28; int v29;
int v30; int v31; int v32; int v33; int v34; int v35; int v36; int v37; int v38; int v39;
int v40; int v41; int v42; int v43; int v44; int v45; int v46; int v47; int v48; int v49;
int v50; int v51; int v52; int v53; int v54; int v55; int v56; int v57; int v58; int v59;
int v60; int v61; int v62; int v63; int v64; int v65; int v66; int v67; int v68; int v69;
int v70; int v71; int v72; int v73; int v74; int v75; int v76; int v77; int v78; int v79;
int v80; int v81; int v82; int v83; int v84; int v85; int v86; int v87; int v88; int v89;
int v90; int v91; int v92; int v93; int v94; int v95; int v96; int v97; int v98; int v99;

int v100; int v101; int v102; int v103; int v104; int v105; int v106; int v107; int v108; int v109;
int v110; int v111; int v112; int v113; int v114; int v115; int v116; int v117; int v118; int v119;
int v120; int v121; int v122; int v123; int v124; int v125; int v126; int v127; int v128; int v129;
int v130; int v131; int v132; int v133; int v134; int v135; int v136; int v137; int v138; int v139;
int v140; int v141; int v142; int v143; int v144; int v145; int v146; int v147; int v148; int v149;
int v150; int v151; int v152; int v153; int v154; int v155; int v156; int v157; int v158; int v159;
int v160; int v161; int v162; int v163; int v164; int v165; int v166; int v167; int v168; int v169;
int v170; int v171; int v172; int v173; int v174; int v175; int v176; int v177; int v178; int v179;
int v180; int v181; int v182; int v183; int v184; int v185; int v186; int v187; int v188; int v189;
int v190; int v191; int v192; int v193; int v194; int v195; int v196; int v197; int v198; int v199;

int v200; int v201; int v202; int v203; int v204; int v205; int v206; int v207; int v208; int v209;
int v210; int v211; int v212; int v213; int v214; int v215; int v216; int v217; int v218; int v219;
int v220; int v221; int v222; int v223; int v224; int v225; int v226; int v227; int v228; int v229;
int v230; int v231; int v232; int v233; int v234; int v235; int v236; int v237; int v238; int v239;
int v240; int v241; int v242; int v243; int v244; int v245; int v246; int v247; int v248; int v249;
int v250; int v251; int v252; int v253; int v254; int v255; int v256; int v257; int v258; int v259;
int v260; int v261; int v262; int v263; int v264; int v265; int v266; int v267; int v268; int v269;
int v270; int v271; int v272; int v273; int v274; int v275; int v276; int v277; int v278; int v279;
int v280; int v281; int v282; int v283; int v284; int v285; int v286; int v287; int v288; int v289;
int v290; int v291; int v292; int v293; int v294; int v295; int v296; int v297; int v298; int v299;

int v300; int v301; int v302; int v303; int v304; int v305; int v306; int v307; int v308; int v309;
int v310; int v311; int v312; int v313; int v314; int v315; int v316; int v317; int v318; int v319;
int v320; int v321; int v322; int v323; int v324; int v325; int v326; int v327; int v328; int v329;
int v330; int v331; int v332; int v333; int v334; int v335; int v336; int v337; int v338; int v339;
int v340; int v341; int v342; int v343; int v344; int v345; int v346; int v347; int v348; int v349;
int v350; int v351; int v352; int v353; int v354; int v355; int v356; int v357; int v358; int v359;
int v360; int v361; int v362; int v363; int v364; int v365; int v366; int v367; int v368; int v369;
int v370; int v371; int v372; int v373; int v374; int v375; int v376; int v377; int v378; int v379;
int v380; int v381; int v382; int v383; int v384; int v385; int v386; int v387; int v388; int v389;
int v390; int v391; int v392; int v393; int v394; int v395; int v396; int v397; int v398; int v399;

v0 = 100; print(v0);
v1 = 101; print(v1);
v2 = 102; print(v2);
v3 = 103; print(v3);
v4 = 104; print(v4);
v5 = 105; print(v5);
v6 = 106; print(v6);
v7 = 107; print(v7);
v8 = 108; print(v8);
v9 = 109; print(v9);

v10 = 110; print(v10);
v11 = 111; print(v11);
v12 = 112; print(v12);
v13 = 113; print(v13);
v14 = 114; print(v14);
v15 = 115; print(v15);
v16 = 116; print(v16);
v17 = 117; print(v17);
v18 = 118; print(v18);
v19 = 119; print(v19);

v20 = 120; print(v20);
v21 = 121; print(v21);
v22 = 122; print(v22);
v23 = 123; print(v23);
v24 = 124; print(v24);
v25 = 125; print(v25);
v26 = 126; print(v26);
v27 = 127; print(v27);
v28 = 128; print(v28);
v29 = 129; print(v29);

v30 = 130; print(v30);
v31 = 131; print(v31);
v32 = 132; print(v32);
v33 = 133; print(v33);
v34 = 134; print(v34);
v35 = 135; print(v35);
v36 = 136; print(v36);
v37 = 137; print(v37);
v38 = 138; print(v38);
v39 = 139; print(v39);

v40 = 140; print(v40);
v41 = 141; print(v41);
v42 = 142; print(v42);
v43 = 143; print(v43);
v44 = 144; print(v44);
v45 = 145; print(v45);
v46 = 146; print(v46);
v47 = 147; print(v47);
v48 = 148; print(v48);
v49 = 149; print(v49);

v50 = 150; print(v50);
v51 = 151; print(v51);
v52 = 152; print(v52);
v53 = 153; print(v53);
v54 = 154; print(v54);
v55 = 155; print(v55);
v56 = 156; print(v56);
v57 = 157; print(v57);
v58 = 158; print(v58);
v59 = 159; print(v59);

v60 = 160; print(v60);
v61 = 161; print(v61);
v62 = 162; print(v62);
v63 = 163; print(v63);
v64 = 164; print(v64);
v65 = 165; print(v65);
v66 = 166; print(v66);
v67 = 167; print(v67);
v68 = 168; print(v68);
v69 = 169; print(v69);

v70 = 170; print(v70);
v71 = 171; print(v71);
v72 = 172; print(v72);
v73 = 173; print(v73);
v74 = 174; print(v74);
v75 = 175; print(v75);
v76 = 176; print(v76);
v77 = 177; print(v77);
v78 = 178; print(v78);
v79 = 179; print(v79);

v80 = 180; print(v80);
v81 = 181; print(v81);
v82 = 182; print(v82);
v83 = 183; print(v83);
v84 = 184; print(v84);
v85 = 185; print(v85);
v86 = 186; print(v86);
v87 = 187; print(v87);
v88 = 188; print(v88);
v89 = 189; print(v89);

v90 = 190; print(v90);
v91 = 191; print(v91);
v92 = 192; print(v92);
v93 = 193; print(v93);
v94 = 194; print(v94);
v95 = 195; print(v95);
v96 = 196; print(v96);
v97 = 197; print(v97);
v98 = 198; print(v98);
v99 = 199; print(v99);

v100 = 200; print(v100);
v101 = 201; print(v101);
v102 = 202; print(v102);
v103 = 203; print(v103);
v104 = 204; print(v104);
v105 = 205; print(v105);
v106 = 206; print(v106);
v107 = 207; print(v107);
v108 = 208; print(v108);
v109 = 209; print(v109);

v110 = 210; print(v110);
v111 = 211; print(v111);
v112 = 212; print(v112);
v113 = 213; print(v113);
v114 = 214; print(v114);
v115 = 215; print(v115);
v116 = 216; print(v116);
v117 = 217; print(v117);
v118 = 218; print(v118);
v119 = 219; print(v119);

v120 = 220; print(v120);
v121 = 221; print(v121);
v122 = 222; print(v122);
v123 = 223; print(v123);
v124 = 224; print(v124);
v125 = 225; print(v125);
v126 = 226; print(v126);
v127 = 227; print(v127);
v128 = 228; print(v128);
v129 = 229; print(v129);

v130 = 230; print(v130);
v131 = 231; print(v131);
v132 = 232; print(v132);
v133 = 233; print(v133);
v134 = 234; print(v134);
v135 = 235; print(v135);
v136 = 236; print(v136);
v137 = 237; print(v137);
v138 = 238; print(v138);
v139 = 239; print(v139);

v140 = 240; print(v140);
v141 = 241; print(v141);
v142 = 242; print(v142);
v143 = 243; print(v143);
v144 = 244; print(v144);
v145 = 245; print(v145);
v146 = 246; print(v146);
v147 = 247; print(v147);
v148 = 248; print(v148);
v149 = 249; print(v149);

v150 = 250; print(v150);
v151 = 251; print(v151);
v152 = 252; print(v152);
v153 = 253; print(v153);
v154 = 254; print(v154);
v155 = 255; print(v155);
v156 = 256; print(v156);
v157 = 257; print(v157);
v158 = 258; print(v158);
v159 = 259; print(v159);

v160 = 260; print(v160);
v161 = 261; print(v161);
v162 = 262; print(v162);
v163 = 263; print(v163);
v164 = 264; print(v164);
v165 = 265; print(v165);
v166 = 266; print(v166);
v167 = 267; print(v167);
v168 = 268; print(v168);
v169 = 269; print(v169);

v170 = 270; print(v170);
v171 = 271; print(v171);
v172 = 272; print(v172);
v173 = 273; print(v173);
v174 = 274; print(v174);
v175 = 275; print(v175);
v176 = 276; print(v176);
v177 = 277; print(v177);
v178 = 278; print(v178);
v179 = 279; print(v179);

v180 = 280; print(v180);
v181 = 281; print(v181);
v182 = 282; print(v182);
v183 = 283; print(v183);
v184 = 284; print(v184);
v185 = 285; print(v185);
v186 = 286; print(v186);
v187 = 287; print(v187);
v188 = 288; print(v188);
v189 = 289; print(v189);

v190 = 290; print(v190);
v191 = 291; print(v191);
v192 = 292; print(v192);
v193 = 293; print(v193);
v194 = 294; print(v194);
v195 = 295; print(v195);
v196 = 296; print(v196);
v197 = 297; print(v197);
v198 = 298; print(v198);
v199 = 299; print(v199);

v200 = 300; print(v200);
v201 = 301; print(v201);
v202 = 302; print(v202);
v203 = 303; print(v203);
v204 = 304; print(v204);
v205 = 305; print(v205);
v206 = 306; print(v206);
v207 = 307; print(v207);
v208 = 308; print(v208);
v209 = 309; print(v209);

v210 = 310; print(v210);
v211 = 311; print(v211);
v212 = 312; print(v212);
v213 = 313; print(v213);
v214 = 314; print(v214);
v215 = 315; print(v215);
v216 = 316; print(v216);
v217 = 317; print(v217);
v218 = 318; print(v218);
v219 = 319; print(v219);

v220 = 320; print(v220);
v221 = 321; print(v221);
v222 = 322; print(v222);
v223 = 323; print(v223);
v224 = 324; print(v224);
v225 = 325; print(v225);
v226 = 326; print(v226);
v227 = 327; print(v227);
v228 = 328; print(v228);
v229 = 329; print(v229);

v230 = 330; print(v230);
v231 = 331; print(v231);
v232 = 332; print(v232);
v233 = 333; print(v233);
v234 = 334; print(v234);
v235 = 335; print(v235);
v236 = 336; print(v236);
v237 = 337; print(v237);
v238 = 338; print(v238);
v239 = 339; print(v239);

v240 = 340; print(v240);
v241 = 341; print(v241);
v242 = 342; print(v242);
v243 = 343; print(v243);
v244 = 344; print(v244);
v245 = 345; print(v245);
v246 = 346; print(v246);
v247 = 347; print(v247);
v248 = 348; print(v248);
v249 = 349; print(v249);

v250 = 350; print(v250);
v251 = 351; print(v251);
v252 = 352; print(v252);
v253 = 353; print(v253);
v254 = 354; print(v254);
v255 = 355; print(v255);
v256 = 356; print(v256);
v257 = 357; print(v257);
v258 = 358; print(v258);
v259 = 359; print(v259);

v260 = 360; print(v260);
v261 = 361; print(v261);
v262 = 362; print(v262);
v263 = 363; print(v263);
v264 = 364; print(v264);
v265 = 365; print(v265);
v266 = 366; print(v266);
v267 = 367; print(v267);
v268 = 368; print(v268);
v269 = 369; print(v269);

v270 = 370; print(v270);
v271 = 371; print(v271);
v272 = 372; print(v272);
v273 = 373; print(v273);
v274 = 374; print(v274);
v275 = 375; print(v275);
v276 = 376; print(v276);
v277 = 377; print(v277);
v278 = 378; print(v278);
v279 = 379; print(v279);

v280 = 380; print(v280);
v281 = 381; print(v281);
v282 = 382; print(v282);
v283 = 383; print(v283);
v284 = 384; print(v284);
v285 = 385; print(v285);
v286 = 386; print(v286);
v287 = 387; print(v287);
v288 = 388; print(v288);
v289 = 389; print(v289);

v290 = 390; print(v290);
v291 = 391; print(v291);
v292 = 392; print(v292);
v293 = 393; print(v293);
v294 = 394; print(v294);
v295 = 395; print(v295);
v296 = 396; print(v296);
v297 = 397; print(v297);
v298 = 398; print(v298);
v299 = 399; print(v299);

v300 = 400; print(v300);
v301 = 401; print(v301);
v302 = 402; print(v302);
v303 = 403; print(v303);
v304 = 404; print(v304);
v305 = 405; print(v305);
v306 = 406; print(v306);
v307 = 407; print(v307);
v308 = 408; print(v308);
v309 = 409; print(v309);

v310 = 410; print(v310);
v311 = 411; print(v311);
v312 = 412; print(v312);
v313 = 413; print(v313);
v314 = 414; print(v314);
v315 = 415; print(v315);
v316 = 416; print(v316);
v317 = 417; print(v317);
v318 = 418; print(v318);
v319 = 419; print(v319);

v320 = 420; print(v320);
v321 = 421; print(v321);
v322 = 422; print(v322);
v323 = 423; print(v323);
v324 = 424; print(v324);
v325 = 425; print(v325);
v326 = 426; print(v326);
v327 = 427; print(v327);
v328 = 428; print(v328);
v329 = 429; print(v329);

v330 = 430; print(v330);
v331 = 431; print(v331);
v332 = 432; print(v332);
v333 = 433; print(v333);
v334 = 434; print(v334);
v335 = 435; print(v335);
v336 = 436; print(v336);
v337 = 437; print(v337);
v338 = 438; print(v338);
v339 = 439; print(v339);

v340 = 440; print(v340);
v341 = 441; print(v341);
v342 = 442; print(v342);
v343 = 443; print(v343);
v344 = 444; print(v344);
v345 = 445; print(v345);
v346 = 446; print(v346);
v347 = 447; print(v347);
v348 = 448; print(v348);
v349 = 449; print(v349);

v350 = 450; print(v350);
v351 = 451; print(v351);
v352 = 452; print(v352);
v353 = 453; print(v353);
v354 = 454; print(v354);
v355 = 455; print(v355);
v356 = 456; print(v356);
v357 = 457; print(v357);
v358 = 458; print(v358);
v359 = 459; print(v359);

v360 = 460; print(v360);
v361 = 461; print(v361);
v362 = 462; print(v362);
v363 = 463; print(v363);
v364 = 464; print(v364);
v365 = 465; print(v365);
v366 = 466; print(v366);
v367 = 467; print(v367);
v368 = 468; print(v368);
v369 = 469; print(v369);

v370 = 470; print(v370);
v371 = 471; print(v371);
v372 = 472; print(v372);
v373 = 473; print(v373);
v374 = 474; print(v374);
v375 = 475; print(v375);
v376 = 476; print(v376);
v377 = 477; print(v377);
v378 = 478; print(v378);
v379 = 479; print(v379);

v380 = 480; print(v380);
v381 = 481; print(v381);
v382 = 482; print(v382);
v383 = 483; print(v383);
v384 = 484; print(v384);
v385 = 485; print(v385);
v386 = 486; print(v386);
v387 = 487; print(v387);
v388 = 488; print(v388);
v389 = 489; print(v389);

v390 = 490; print(v390);
v391 = 491; print(v391);
v392 = 492; print(v392);
v393 = 493; print(v393);
v394 = 494; print(v394);
v395 = 495; print(v395);
v396 = 496; print(v396);
v397 = 497; print(v397);
v398 = 498; print(v398);
v399 = 499; print(v399);

